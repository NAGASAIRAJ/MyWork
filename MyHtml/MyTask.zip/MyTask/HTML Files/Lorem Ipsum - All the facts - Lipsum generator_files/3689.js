BAP.copyJSON({
  "data": {
    "icon_position": "top-right",
    "default_icon": "_us",
    "mobile_in_app_url": "",
    "default_footer": "Privacy Controls by Evidon, Inc.",
    "icon_display": "expandable",
    "icon_grayscale": 30,
    "container_opacity": 70,
    "offset_x": 0,
    "offset_y": 0,
    "generic_icon": false,
    "icon_delay": 0,
    "nid": 3689,
    "nwid": null,
    "aid": 290,
    "icid": null,
    "skip_L2": false,
    "behavioral": "uncertain",
    "generic_text": null,
    "adv_name": "MediaMath",
    "adv_msg": "MediaMath Privacy Policy",
    "adv_logo": "http://c.betrad.com/a/l/n/290/3689/us/1314898451571.png",
    "adv_link": "http://www.mediamath.com/privacy-policy/",
    "mobile_message": "Tap to edit advertising preferences",
    "display_mobile_overlay": false,
    "mobile_advertiser_logo_url": "",
    "default_icon_text": "AdChoices",
    "default_generic1": "This ad has been matched to your interests. It was selected for you based on your browsing activity.",
    "default_generic2": "This ad may have been matched to your interests based on your browsing activity.",
    "default_generic3": "helped",
    "default_generic4": "determine that you might be interested in an ad like this.",
    "default_generic5": "select this ad for you.",
    "default_generic6": "selected this ad for you.",
    "default_link1": "More information & opt-out options",
    "default_link2": "What is interest based advertising",
    "default_link3": "Learn about your choices",
    "ecid": null,
    "hide_wi": false,
    "hide_cl": false,
    "server": [
      {
        "name": "MediaMath"
      }
    ],
    "message_properties": {
      "skip_L2_gb": true,
      "translation_gb": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_ar": true,
      "translation_ar": {
        "icon": "_es",
        "icon_text": "Selecci&#243;n de Publicidad "
      },
      "skip_L2_at": true,
      "translation_at": {
        "icon": "_de",
        "icon_text": "Datenschutzinfo"
      },
      "skip_L2_be": true,
      "translation_be": {
        "icon": "_nl_be",
        "icon_text": "Info reclamekeuze"
      },
      "skip_L2_br": true,
      "translation_br": {
        "icon": "_pt_br",
        "icon_text": "MaisEscolhas"
      },
      "skip_L2_bg": true,
      "translation_bg": {
        "icon": "_bg",
        "icon_text": "&#1042;&#1072;&#1096;&#1080;&#1103;&#1090; &#1080;&#1079;&#1073;&#1086;&#1088;"
      },
      "skip_L2_ca": true,
      "translation_ca": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_cn": true,
      "translation_cn": {
        "icon": "_cn",
        "icon_text": "&#24191;&#21578;&#36873;&#25321;"
      },
      "skip_L2_cy": true,
      "translation_cy": {
        "icon": "_gr",
        "icon_text": "&#927;&#953; &#948;&#953;&#945;&#966;&#951;&#956;&#953;&#769;&#963;&#949;&#953;&#962; &#956;&#959;&#965;"
      },
      "skip_L2_cz": true,
      "translation_cz": {
        "icon": "_cz",
        "icon_text": "Volby reklamy"
      },
      "skip_L2_dk": true,
      "translation_dk": {
        "icon": "_dk",
        "icon_text": "Annoncevalg"
      },
      "skip_L2_ee": true,
      "translation_ee": {
        "icon": "_ee",
        "icon_text": "Reklaamivalikud"
      },
      "skip_L2_fi": true,
      "translation_fi": {
        "icon": "_fi",
        "icon_text": "Mainokseni"
      },
      "skip_L2_fr": true,
      "translation_fr": {
        "icon": "_fr",
        "icon_text": "Choisir sa pub"
      },
      "skip_L2_de": true,
      "translation_de": {
        "icon": "_de",
        "icon_text": "Datenschutzinfo"
      },
      "skip_L2_gr": true,
      "translation_gr": {
        "icon": "_gr",
        "icon_text": "&#927;&#953; &#948;&#953;&#945;&#966;&#951;&#956;&#953;&#769;&#963;&#949;&#953;&#962; &#956;&#959;&#965;"
      },
      "skip_L2_hu": true,
      "translation_hu": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_is": true,
      "translation_is": {
        "icon": "_is",
        "icon_text": "Augl&#253;singaValkostir"
      },
      "skip_L2_ie": true,
      "translation_ie": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_it": true,
      "translation_it": {
        "icon": "_it",
        "icon_text": "Scegli tu!"
      },
      "skip_L2_jp": true,
      "translation_jp": {
        "icon": "_jp",
        "icon_text": "&#12450;&#12489;&#12481;&#12519;&#12452;&#12473;"
      },
      "skip_L2_kr": true,
      "translation_kr": {
        "icon": "_kr",
        "icon_text": "&#50528;&#46300;&#52488;&#51060;&#49828;"
      },
      "skip_L2_lv": true,
      "translation_lv": {
        "icon": "_lv",
        "icon_text": "AdChoices"
      },
      "skip_L2_lt": true,
      "translation_lt": {
        "icon": "_lt",
        "icon_text": "Skelbim&#371; pasirinkimas"
      },
      "skip_L2_lu": true,
      "translation_lu": {
        "icon": "_de",
        "icon_text": "Datenschutzinfo"
      },
      "skip_L2_mt": true,
      "translation_mt": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_mx": true,
      "translation_mx": {
        "icon": "_es",
        "icon_text": "Selecci&#243;n de Publicidad "
      },
      "skip_L2_nl": true,
      "translation_nl": {
        "icon": "_nl",
        "icon_text": "Info"
      },
      "skip_L2_no": true,
      "translation_no": {
        "icon": "_no",
        "icon_text": "Annonsevalg"
      },
      "skip_L2_pl": true,
      "translation_pl": {
        "icon": "_pl",
        "icon_text": "Informacja"
      },
      "skip_L2_pt": true,
      "translation_pt": {
        "icon": "_pt",
        "icon_text": "MaisEscolhas"
      },
      "skip_L2_ro": true,
      "translation_ro": {
        "icon": "_ro",
        "icon_text": "Optiuni"
      },
      "skip_L2_ru": true,
      "translation_ru": {
        "icon": "_ru",
        "icon_text": "AdChoices"
      },
      "skip_L2_sk": true,
      "translation_sk": {
        "icon": "_sk",
        "icon_text": "Vas&#780;a vol&#780;ba"
      },
      "skip_L2_si": true,
      "translation_si": {
        "icon": "_si",
        "icon_text": "OglasneMo&#382;nosti"
      },
      "skip_L2_es": true,
      "translation_es": {
        "icon": "_es",
        "icon_text": "Gestio&#769;n anuncios"
      },
      "skip_L2_se": true,
      "translation_se": {
        "icon": "_se",
        "icon_text": "Annonsval"
      },
      "skip_L2_ch": true,
      "translation_ch": {
        "icon": "_fr",
        "icon_text": "Choisir sa pub"
      },
      "skip_L2_tw": true,
      "translation_tw": {
        "icon": "_tw",
        "icon_text": "&#24291;&#21578;&#36984;&#25799;"
      },
      "skip_L2_au": true,
      "translation_au": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_sg": true,
      "translation_sg": {
        "icon": "_cn",
        "icon_text": "&#24191;&#21578;&#36873;&#25321;"
      },
      "skip_L2_hk": true,
      "translation_hk": {
        "icon": "_tw",
        "icon_text": "&#24291;&#21578;&#36984;&#25799;"
      },
      "skip_L2_hr": true,
      "translation_hr": {
        "icon": "_hr",
        "icon_text": "Izbor reklama"
      },
      "skip_L2_in": true,
      "translation_in": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_mk": true,
      "translation_mk": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_nz": true,
      "translation_nz": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_rs": true,
      "translation_rs": {
        "icon": "_rs",
        "icon_text": "Opcije oglasa"
      },
      "skip_L2_eg": true,
      "translation_eg": {
        "icon": "_ar_eg",
        "icon_text": "خيارات إعلانية"
      },
      "skip_L2_id": true,
      "translation_id": {
        "icon": "_id",
        "icon_text": "AdChoices"
      },
      "skip_L2_il": true,
      "translation_il": {
        "icon": "_il",
        "icon_text": "&#1508;&#1512;&#1505;&#1493;&#1502;&#1493;&#1514; &#1500;&#1489;&#1495;&#1497;&#1512;&#1492;"
      },
      "skip_L2_my": true,
      "translation_my": {
        "icon": "_ms",
        "icon_text": "AdChoices"
      },
      "skip_L2_ph": true,
      "translation_ph": {
        "icon": "_ph",
        "icon_text": "AdChoices"
      },
      "skip_L2_th": true,
      "translation_th": {
        "icon": "_th",
        "icon_text": "AdChoices"
      },
      "skip_L2_tr": true,
      "translation_tr": {
        "icon": "_tr",
        "icon_text": "ReklamTercihleri"
      },
      "skip_L2_am": true,
      "translation_am": {
        "icon": "_am",
        "icon_text": "AdChoices"
      },
      "skip_L2_ua": true,
      "translation_ua": {
        "icon": "_ua",
        "icon_text": "AdChoices"
      },
      "skip_L2_al": true,
      "translation_al": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_ai": true,
      "translation_ai": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_aw": true,
      "translation_aw": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_bm": true,
      "translation_bm": {
        "icon": "_us",
        "icon_text": "AdChoices"
      },
      "skip_L2_ag": true,
      "translation_ag": {
        "icon": "_us",
        "icon_text": "AdChoices"
      }
    }
  }
});